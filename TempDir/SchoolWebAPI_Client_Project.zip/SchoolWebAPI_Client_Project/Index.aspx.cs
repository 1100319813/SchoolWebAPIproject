﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SchoolWebAPI_Client_Project
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dtable = new DataTable();
                dtable.Clear();
                dtable.Columns.Add("Id");
                dtable.Columns.Add("Author");
                dtable.Columns.Add("Title");
                dtable.Columns.Add("ISBN");
                dtable.Columns.Add("Pages");

                DataRow drow = dtable.NewRow();
                drow["Id"] = "1";
                drow["Author"] = "Bulgakov";
                drow["Title"] = "Master";
                drow["ISBN"] = "1234567890987";
                drow["Pages"] = "256";

                dtable.Rows.Add(drow);

                //var client = new RestClient("https://localhost:44357");
                //var request = new RestRequest("/api/books", Method.GET);
                //request.RequestFormat = DataFormat.Json;

                System.Net.WebRequest req = System.Net.WebRequest.Create("https://localhost:44357/api/books");
                req.Method = "GET";
                //req.Headers.Add("key");
                req.ContentType = "application/json; charset=utf-8";

                System.Net.WebResponse resp = req.GetResponse();
                System.IO.Stream stream = resp.GetResponseStream();

                StreamReader re = new StreamReader(stream);

                String json = re.ReadToEnd();

                json = "{\"Author\":" + json + "}";

                //wrapper w = (wrapper)new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize(json, typeof(wrapper));

                gvSchoolLibrary.DataSource = dtable;
                gvSchoolLibrary.DataBind();
            }
        }
    }
}